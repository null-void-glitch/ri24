/**
 * RI24 Baufinanzierungs-Assistent – Partner-Widget-Engine
 * =========================================================
 * Für EXTERNE Berater-Webseiten (nicht auf regionalimmobilien24.de). Anders
 * als embed-snippet.html (das die eigene RI24-Berater-Seite per `berater_url`
 * live über den MCP-Server scraped, siehe advisor-resolver.php) ist die
 * Berater-Zuordnung hier vorab fest hinterlegt: Jede externe Partner-Seite
 * bekommt eine feste `beraterId`. Die eigentlichen Kontaktdaten bleiben
 * trotzdem zentral in advisors.php gepflegt — resolve_advisor() löst die ID
 * genauso auf wie beim `?berater=`-Deep-Link der Landingpage, nur dass hier
 * nie ein Cookie/Zufall zum Zug kommt, weil die ID bei jedem Request explizit
 * mitgeschickt wird.
 *
 * Einbindung auf der externen Berater-Seite (zwei <script>-Tags, sonst nichts):
 *
 *   <script>
 *     window.RI24_BAUFI_PARTNER_WIDGET = {
 *       beraterId: 'philipp-steppohn',   // ← pro Berater anpassen
 *       mode: 'bubble',                  // 'bubble' (Floating-Launcher) oder 'inline'
 *       accentColor: '#c0392b'           // optional: Marken-Farbe des Partners (6-stelliger Hex-Code)
 *     };
 *   </script>
 *   <script src="https://www.regionalimmobilien24.de/api/chat-baufinanzierung/partner-widget.js"></script>
 *
 * mode 'inline': der Chat wird direkt an der Stelle eingefügt, an der das
 * zweite <script>-Tag im HTML steht (wie embed-snippet.html).
 * mode 'bubble': das Skript baut selbst einen Floating-Launcher-Button unten
 * rechts + ein Chat-Panel, das beim Klick auf-/zuklappt — die Partnerseite
 * muss dafür nichts weiter vorbereiten.
 *
 * accentColor (optional): färbt Buttons, Header, Launcher und Nutzer-Bubble in
 * der Marken-Farbe des Partners statt im RI24-Grün. Helle Hintergrundtöne (KI-
 * Bubble, Hinweis-Leiste) werden automatisch als aufgehellte Variante davon
 * berechnet. Ungültige/fehlende Werte fallen auf RI24-Grün (#0b6b3a) zurück.
 *
 * Bekannte Grenze: läuft ohne Shadow-DOM-Isolation, d.h. global gesetzte CSS-
 * Resets auf der Partnerseite (z.B. `button { all: unset }`) können das
 * Widget verformen. Für die ersten Partner-Rollouts bewusst einfach gehalten;
 * bei Bedarf später auf Shadow DOM umstellen.
 */
(function () {
  'use strict';

  var cfg = window.RI24_BAUFI_PARTNER_WIDGET || {};
  if (!cfg.beraterId) {
    console.error('[RI24 Baufi Widget] RI24_BAUFI_PARTNER_WIDGET.beraterId fehlt – Widget wird nicht geladen.');
    return;
  }

  var BERATER_ID = cfg.beraterId;
  var MODE = cfg.mode === 'inline' ? 'inline' : 'bubble';
  // Absolute URLs nötig: dieses Skript läuft im Kontext der PARTNER-Seite,
  // relative Pfade würden gegen deren Origin statt gegen unsere API auflösen.
  var ENDPOINT = cfg.endpoint || 'https://www.regionalimmobilien24.de/api/chat-baufinanzierung/chat.php';
  var RESOLVE_ENDPOINT = cfg.resolveEndpoint || 'https://www.regionalimmobilien24.de/api/chat-baufinanzierung/resolve-advisor.php';

  // Muss synchron beim Laden erfasst werden – in einer async-Callback wäre
  // document.currentScript bereits wieder null.
  var insertionPoint = document.currentScript;

  // Farbe der Bedienelemente (Buttons, Header, Launcher, Nutzer-Bubble) an die
  // Marke des externen Partners anpassbar via `accentColor` (6-stelliger Hex-
  // Code, z.B. '#c0392b'). Fällt auf RI24-Grün zurück, wenn nicht gesetzt oder
  // ungültig. Der helle Hintergrundton (KI-Bubble, Hinweis-Leiste) wird daraus
  // automatisch abgeleitet, damit Partner nicht zwei Farben pflegen müssen.
  var GREEN = isValidHexColor(cfg.accentColor) ? cfg.accentColor : '#0b6b3a';
  var GREEN_BG = lighten(GREEN, 0.94);

  function isValidHexColor(v) {
    return typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v);
  }

  function lighten(hex, amount) {
    var r = parseInt(hex.slice(1, 3), 16);
    var g = parseInt(hex.slice(3, 5), 16);
    var b = parseInt(hex.slice(5, 7), 16);
    var mix = function (c) { return Math.round(c + (255 - c) * amount); };
    return 'rgb(' + mix(r) + ',' + mix(g) + ',' + mix(b) + ')';
  }

  // EU AI Act Art. 50: Nutzer muss jederzeit erkennen können, dass er mit
  // einer KI statt einem Menschen interagiert — daher als dauerhaft
  // sichtbares Label, nicht nur einmalig in der Willkommensnachricht.
  var DISCLOSURE_TEXT = '🤖 KI-generierter Inhalt';

  var conversationId = (window.crypto && crypto.randomUUID)
    ? crypto.randomUUID()
    : 'c' + Date.now() + Math.random().toString(36).slice(2);

  // Wie in embed-snippet.html: DeepChat lädt als type="module" deferred; ohne
  // whenDefined() würde die Konfiguration vor dem "Upgrade" des Custom
  // Elements greifen und der Chat startet im Demo-Modus.
  function ensureDeepChat(cb) {
    if (window.customElements && customElements.get('deep-chat')) { cb(); return; }
    if (!document.querySelector('script[data-ri24-baufi-deepchat]')) {
      var s = document.createElement('script');
      s.type = 'module';
      s.src = 'https://cdn.jsdelivr.net/npm/deep-chat@2/dist/deepChat.bundle.js';
      s.setAttribute('data-ri24-baufi-deepchat', '1');
      document.head.appendChild(s);
    }
    customElements.whenDefined('deep-chat').then(cb);
  }

  function fetchAdvisor() {
    return fetch(RESOLVE_ENDPOINT + '?berater=' + encodeURIComponent(BERATER_ID))
      .then(function (res) { return res.ok ? res.json() : null; })
      .catch(function () { return null; });
  }

  // advisors.php pflegt `photo` bisher als Pfad relativ zur Landingpage (z.B.
  // "assets/philipp-steppohn.png") — auf einer fremden Partner-Domain (oder
  // hier lokal) kann das ins Leere zeigen. Statt eines kaputten Bild-Icons
  // fällt das Foto bei Ladefehler automatisch auf Initialen/Emoji zurück.
  function avatarMarkup(advisor, sizePx, fontSize, fallbackBg) {
    var fallback = (advisor && advisor.avatarInitials) ? advisor.avatarInitials : '💬';
    var hasPhoto = !!(advisor && advisor.photo);
    var fallbackSpan =
      '<span style="display:' + (hasPhoto ? 'none' : 'flex') + ';' +
        'position:absolute;inset:0;border-radius:50%;background:' + fallbackBg + ';' +
        'align-items:center;justify-content:center;font-size:' + fontSize + ';font-weight:600;">' +
        fallback + '</span>';
    var imgHtml = hasPhoto
      ? '<img src="' + advisor.photo + '" alt="" ' +
          'style="width:100%;height:100%;border-radius:50%;object-fit:cover;" ' +
          'onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\';">'
      : '';
    return '<span style="position:relative;display:inline-flex;width:' + sizePx + 'px;height:' + sizePx + 'px;flex:0 0 auto;">' +
      imgHtml + fallbackSpan + '</span>';
  }

  // <deep-chat> ist per Default ein `display:table-cell`-Element und legt
  // intern (Shadow DOM) einen Nachrichten-Container mit `overflow-x:auto` an,
  // der bei manchen Zoom-/Font-Kombinationen 1px breiter ist als sein
  // sichtbarer Bereich — auf Systemen mit klassischen (nicht-Overlay-)
  // Scrollbars (Linux/Windows) erscheint dadurch ein sichtbarer horizontaler
  // Scrollbalken. Eine ins Shadow-DOM injizierte Regel unterdrückt das
  // zuverlässig, unabhängig von der genauen internen Struktur.
  function suppressHorizontalScrollbar(chat) {
    if (!chat.shadowRoot) return;
    var style = document.createElement('style');
    style.textContent = '* { overflow-x: hidden !important; }';
    chat.shadowRoot.appendChild(style);
  }

  function buildChatElement(advisor) {
    var chat = document.createElement('deep-chat');
    suppressHorizontalScrollbar(chat);

    chat.connect = { url: ENDPOINT, method: 'POST', stream: true };
    chat.requestInterceptor = function (requestDetails) {
      requestDetails.body.conversation_id = conversationId;
      requestDetails.body.berater_id = BERATER_ID; // fest zugeordnet, kein Live-Scrape
      return requestDetails;
    };

    chat.textInput = {
      placeholder: { text: 'Frag mich etwas zu deiner Baufinanzierung …' },
      styles: { text: { color: '#111' } }
    };
    chat.submitButtonStyles = {
      submit: {
        container: { default: { backgroundColor: GREEN, width: '2.4rem', height: '2.4rem', borderRadius: '50%' } },
        svg: { styles: { default: { width: '45%', height: '45%' } } }
      }
    };
    chat.messageStyles = {
      default: {
        ai:   { bubble: { backgroundColor: GREEN_BG, color: '#111' } },
        user: { bubble: { backgroundColor: GREEN, color: '#fff' } }
      }
    };
    chat.htmlClassUtilities = {
      'ri24-starter': {
        events: {
          click: function (event) { chat.submitUserMessage({ text: event.target.textContent.trim() }); }
        },
        styles: {
          default: {
            display: 'block', width: '100%', textAlign: 'left', cursor: 'pointer',
            margin: '6px 0', padding: '10px 12px', borderRadius: '10px',
            border: '1px solid #d7ddd9', backgroundColor: '#fff', color: GREEN,
            fontSize: '0.9rem'
          },
          hover: { backgroundColor: GREEN_BG }
        }
      }
    };

    var greeting = advisor && advisor.name
      ? 'Ich bin der Baufinanzierungs-Assistent von <b>' + advisor.name + '</b>' +
        (advisor.title ? ' (' + advisor.title + ')' : '') + '.'
      : 'Ich bin dein Baufinanzierungs-Assistent.';

    chat.introMessage = {
      html:
        '<div style="line-height:1.5">' +
          '<b>👋 Willkommen!</b><br>' + greeting + ' ' +
          'Ich helfe dir, deine Finanzierung durchzurechnen und zu optimieren.' +
          '<div style="margin-top:10px">' +
            '<div class="ri24-starter">Wie hoch könnte meine monatliche Rate sein? 💰</div>' +
            '<div class="ri24-starter">Wie kann ich meine Finanzierung optimieren? 📈</div>' +
            '<div class="ri24-starter">Was ist eine Anschlussfinanzierung? ❓</div>' +
            '<div class="ri24-starter">Ich möchte einen Beratungstermin buchen 📅</div>' +
          '</div>' +
        '</div>'
    };

    return chat;
  }

  function disclosureBar() {
    var bar = document.createElement('div');
    bar.style.cssText =
      'box-sizing:border-box;width:100%;max-width:420px;background:' + GREEN_BG + ';color:#333;' +
      'border:1px solid #e2e5ea;border-bottom:none;border-radius:14px 14px 0 0;' +
      'padding:7px 14px;font-size:.76rem;line-height:1.3;' +
      'font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;';
    bar.textContent = DISCLOSURE_TEXT;
    return bar;
  }

  function mountInline(chat) {
    chat.style =
      'display:block;border-radius:0 0 14px 14px;border:1px solid #e2e5ea;border-top:none;' +
      'width:100%;max-width:420px;height:600px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;';

    var bar = disclosureBar();
    if (insertionPoint && insertionPoint.parentNode) {
      insertionPoint.insertAdjacentElement('afterend', bar);
      bar.insertAdjacentElement('afterend', chat);
    } else {
      document.body.appendChild(bar);
      document.body.appendChild(chat);
    }
  }

  function mountBubble(chat, advisor) {
    // display:block nötig: <deep-chat> ist per Default display:table-cell,
    // worauf height:100% nicht wie bei einem Block-Element auf die volle
    // Höhe des Flex-Containers skaliert (sonst bleibt der Chat zu niedrig
    // und es entsteht eine Lücke zwischen Eingabefeld und Panel-Unterkante).
    chat.style = 'display:block;border:none;width:100%;height:100%;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;';

    var panel = document.createElement('div');
    panel.setAttribute('aria-hidden', 'true');
    panel.style.cssText =
      'position:fixed;z-index:2147483000;bottom:96px;right:20px;width:380px;max-width:92vw;' +
      'height:min(600px,80vh);background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.22);' +
      'display:none;flex-direction:column;overflow:hidden;';

    var header = document.createElement('div');
    header.style.cssText =
      'display:flex;align-items:center;gap:10px;padding:12px 14px;background:' + GREEN + ';color:#fff;' +
      'font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;flex:0 0 auto;';
    header.innerHTML =
      avatarMarkup(advisor, 32, '.8rem', 'rgba(255,255,255,.25)') +
      '<div style="flex:1 1 auto;min-width:0;">' +
        '<div style="font-weight:600;font-size:.92rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' +
          'Baufinanzierungs-Assistent' +
        '</div>' +
        (advisor && advisor.name
          ? '<div style="font-size:.78rem;opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + advisor.name + '</div>'
          : '') +
        '<div style="font-size:.7rem;opacity:.85;margin-top:2px;">' + DISCLOSURE_TEXT + '</div>' +
      '</div>';
    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.setAttribute('aria-label', 'Chat schließen');
    closeBtn.innerHTML = '✕';
    closeBtn.style.cssText =
      'background:transparent;border:none;color:#fff;font-size:1.1rem;cursor:pointer;padding:4px 6px;flex:0 0 auto;line-height:1;';
    header.appendChild(closeBtn);

    var body = document.createElement('div');
    body.style.cssText = 'flex:1 1 auto;min-height:0;';
    body.appendChild(chat);

    panel.appendChild(header);
    panel.appendChild(body);

    var launcher = document.createElement('button');
    launcher.type = 'button';
    launcher.setAttribute('aria-label', 'Chat öffnen');
    launcher.setAttribute('aria-expanded', 'false');
    launcher.style.cssText =
      'position:fixed;z-index:2147483000;bottom:20px;right:20px;width:60px;height:60px;border-radius:50%;' +
      'background:' + GREEN + ';border:none;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.25);' +
      'display:flex;align-items:center;justify-content:center;padding:0;overflow:hidden;';
    launcher.innerHTML = avatarMarkup(advisor, 60, '26px', 'transparent');

    var open = false;
    function setOpen(next) {
      open = next;
      panel.style.display = open ? 'flex' : 'none';
      panel.setAttribute('aria-hidden', open ? 'false' : 'true');
      launcher.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    launcher.addEventListener('click', function () { setOpen(!open); });
    closeBtn.addEventListener('click', function () { setOpen(false); });

    document.body.appendChild(panel);
    document.body.appendChild(launcher);
  }

  ensureDeepChat(function () {
    fetchAdvisor().then(function (advisor) {
      var chat = buildChatElement(advisor);
      if (MODE === 'inline') {
        mountInline(chat);
      } else {
        mountBubble(chat, advisor);
      }
    });
  });
})();
