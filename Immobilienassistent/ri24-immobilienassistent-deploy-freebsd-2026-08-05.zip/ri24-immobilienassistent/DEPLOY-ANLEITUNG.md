# RI24 Immobilienassistent – Deploy-Anleitung für Backend (FreeBSD)

Dieses Paket bringt den **bereits laufenden MCP-Server auf den vollen aktuellen
Funktionsstand** (inkl. Fix der Kontaktanfrage, Finanzierungsanfrage-Flow,
siehe 3.1) und liefert **vier** Frontend-Komponenten: den Exposé-Chat, den
eigenständigen Baufinanzierungs-Assistenten (inkl. externem Partner-Widget)
und dessen Landingpage. Alle Befehle/Pfade sind auf **FreeBSD** (`pkg`,
`rc.d`, `sysrc`, php-fpm + nginx) zugeschnitten.

> **Kurzfassung für Eilige**
> 1. MCP-Server: `mcp-server/server/src/` in das bestehende Server-Repo
>    übernehmen, `npm install && npm run build`, `service ri24_mcp restart`.
> 2. Exposé-Chat: Ordner `chat/` unter `…/api/chat/` ablegen, `config.local.php`
>    (oder php-fpm-Pool-`env[...]`) mit OpenAI-Key + `MCP_SERVER_URL` befüllen.
>    Inhalt aus `chat/embed-snippet.html` ins Exposé-Template einbinden.
> 3. Baufinanzierungs-Assistent: Ordner `chat-baufinanzierung/` unter
>    `…/api/chat-baufinanzierung/` ablegen, eigene Konfiguration setzen (4a.2).
>    `chat-baufinanzierung/embed-snippet.html` auf JEDER persönlichen
>    Berater-Seite einbinden; `baufinanzierung-landingpage/` unter
>    `/baufinanzierung/finanzierungsassistent` deployen.
> 4. Externe Partner-Widgets: pro Partner eine Kopiervorlage aus
>    `chat-baufinanzierung/partner-widget-snippet-*.example.html` mit fester
>    `beraterId` (+ optional `accentColor`) an den Partner geben (5.4).

---

## 1. Architektur

```
 Browser (Exposé-Seite)                Browser (Berater-Seite / Landingpage /
   │  DeepChat (embed-snippet.html)      externe Partner-Seite)
   │  POST /api/chat/chat.php              │  DeepChat (embed-snippet.html /
   ▼    { text, expose_url, ... }          │  partner-widget.js)
 chat.php  (PHP-Proxy)                     │  POST /api/chat-baufinanzierung/chat.php
   │  OpenAI Responses API (stream:true)   ▼    { text, berater_url | berater_id, ... }
   │  tools:[{ type:"mcp", ... }]        chat-baufinanzierung/chat.php  (eigener Proxy)
   ▼                                        │  OpenAI Responses API (stream:true)
 MCP-Server  (Node/Express, SSE /mcp/sse)   │  tools:[{ type:"mcp" }, { type:"file_search" }?]
   │  getExposeData, searchNearby,          ▼
   │  Finanzierung, Vorschläge,           derselbe MCP-Server
   │  Calendly, Kontakt-/Finanzierungs-      (createVorschlaege/getVorschlaege,
   │  anfrage, scrapeBeraterPage …           kein Objektbezug nötig)
   ▼
 regionalimmobilien24.de  (OpenImmo-Feed, Europace, Kontakt-/Berater-Endpunkte)
   + Google Places + Calendly
```

Der **OpenAI-API-Key liegt ausschließlich in den PHP-Proxys** (`chat/chat.php`
und `chat-baufinanzierung/chat.php`, jeweils eigener Key/eigene Config) –
niemals im Frontend. Beide Proxys sprechen **denselben** MCP-Server an.

---

## 2. Paketinhalt

```
ri24-immobilienassistent/
├── DEPLOY-ANLEITUNG.md                  ← dieses Dokument
├── system-prompt.md                     ← Agent-Instructions Exposé-Chat (von chat/chat.php gelesen)
├── system-prompt-baufinanzierung.md     ← Agent-Instructions Baufinanzierungs-Assistent
├── chat/                                ← Exposé-Chat: PHP-Proxy + Frontend-Einbindung
│   ├── chat.php / config.php / config.local.php.example
│   ├── embed-snippet.html               ← Einbettungs-Snippet fürs Exposé-Template
│   ├── index.html / test-expose.html    ← Standalone-Demo / Test-Exposé
│   ├── beispiel-expose-prototyp.html    ← Referenz: Inline- + Popup-Einbindung
│   ├── heyregio.svg                     ← Branding-Logo
│   └── README.md
├── chat-baufinanzierung/                ← Eigenständiger Baufinanzierungs-Assistent
│   ├── chat.php / config.php / config.local.php.example
│   ├── advisors.php                     ← Dummy-Berater-Datenbasis (Fallback, vor Go-Live prüfen)
│   ├── advisor-resolver.php             ← resolve_advisor(): berater_id → berater_url-Live-Scrape → Cookie → Zufall
│   ├── resolve-advisor.php              ← JSON-Endpoint für Berater-Card/Widget-Anzeige
│   ├── embed-snippet.html               ← Einbettung auf den EIGENEN RI24-Berater-Seiten
│   ├── partner-widget.js                ← Widget-Engine für EXTERNE Partner-Domains (Bubble/Inline, feste beraterId, accentColor)
│   ├── partner-widget-snippet-*.example.html  ← Kopiervorlagen für externe Berater
│   ├── partner-widget-demo-*.html       ← lokale Test-/Demo-Seiten für das Partner-Widget
│   ├── index.html                       ← Standalone-Demo
│   ├── wissensbasis_baufinanzierung_chatbot_v1_4.json  ← Quelle für den OpenAI Vector Store (file_search)
│   └── README.md
├── baufinanzierung-landingpage/         ← Eigene Unterseite (Ziel: /baufinanzierung/finanzierungsassistent)
│   ├── Baufinanzierung-Prototyp-Chat.html
│   └── assets/                          ← Header-Bild, Navbar-Bild, Berater-Foto(s)
└── mcp-server/                          ← erweiterter MCP-Server (Monorepo: server + web)
    ├── package.json                     ← npm-Workspaces-Root (baut server + web)
    ├── CHATGPT-APP-DEPLOYMENT.md         ← erprobte Deploy-Anleitung der ChatGPT-App (FreeBSD/nginx/SSL)
    ├── server/                          ← MCP-Server (Node/Express)
    │   ├── src/{index,db,calendly,contact}.ts
    │   ├── package.json / tsconfig.json / .env.example
    ├── web/                             ← React-Widget der ChatGPT-App (real-estate-board)
    │   ├── src/…, index.html, vite.config.ts, tailwind.config.js …   ← Quelle (neu baubar)
    │   └── dist/                        ← vorgebautes Widget-Bundle, PFLICHT für `search_real_estate`
    ├── calendly-cookies.json            ← ⚠️ sensibel: Calendly-Admin-Session
    └── deploy/
        ├── nginx-ri24-mcp.conf          ← nginx-Reverse-Proxy (SSE-tauglich)
        └── ri24_mcp.rc                  ← FreeBSD-rc.d-Service-Script
```

---

## 3. Teil A – MCP-Server aktualisieren

### 3.1 Was ist neu ggü. dem aktuell deployten Stand

Der aktuell laufende Server hat einen **älteren Funktionsstand**. Dieses Paket
enthält den **kompletten aktuellen Umfang**. Am einfachsten und sichersten:
`server/src/` **vollständig ersetzen** und neu bauen – dann ist garantiert alles
enthalten. Die wesentlichen Ergänzungen gegenüber dem alten Stand:

- **Kontaktanfrage** (`submitContactInquiry`) – sendet an den internen
  Chatbot-Kontakt-Endpoint (Makler/Anbieter).
- **NEU – Finanzierungsanfrage** (`submitFinancingInquiry`) – sendet DIREKT an
  den namentlich genannten Finanzierungsberater (eigenes Kontaktformular),
  NICHT an den Makler. Wichtigster Unterschied zu `submitContactInquiry`: eine
  Finanzierungsanfrage ist keine Kontaktanfrage an den Makler – beide Tools
  verwechseln ist der laut `system-prompt.md` „häufigste Fehler". Siehe
  System-Prompt Abschnitt 5.3.
- **Personalisierte Finanzierungs-Vorschläge** (`createVorschlaege` /
  `getVorschlaege`) über die Europace-Vorschläge-API – funktioniert **ohne**
  Objekt-OID, das ist die Grundlage des eigenständigen
  Baufinanzierungs-Assistenten (Teil C).
- **NEU – Berater-Seiten-Scrape** (`scrapeBeraterPage()`, intern über
  `GET /gpt/berater?url=...`, kein eigenständiges MCP-Tool): liest Name, Foto,
  Kontaktdaten einer persönlichen Berater-Seite live aus – Grundlage für
  `chat-baufinanzierung/advisor-resolver.php` (Teil C). Nutzt dieselbe
  `[data-xdata]`-Auswertung wie der Berater-Block des Exposé-Chats.
  **Zusätzlich:** ein `oidCache` (Map pro `expose_url`) vermeidet, dass
  `getExposeData` und `submitContactInquiry` dieselbe Exposé-Seite für die
  Objekt-ID zweimal scrapen (weniger Bot-Wall-Fläche, weniger Latenz).
- **428/451-Bot-Wall-Bypass** für `regionalimmobilien24.de` (pitcom „Bin ich ein
  Roboter?"): der Server holt sich per Handshake ein `human`-Cookie und
  wiederholt geblockte Requests automatisch (siehe `index.ts`, Abschnitt
  „pitcom … Bypass").
- **Calendly-Verfügbarkeit + Buchung** und der komplette **Finanzierungs-Flow**
  (`createProcessCode` / `getFinanzierung` / `updateFinanzierung`).
- **Fix Kontaktanfrage** (`submitContactInquiry`): Der Backend-Endpoint erwartet
  `application/x-www-form-urlencoded` (klassische PHP-`$_POST`-Route), nicht JSON
  wie zuvor gesendet. Zusätzlich liest der Server jetzt vorab per `scrapeOid()`
  die Objekt-ID (`.objnr` auf der Exposé-Seite) und übergibt sie als Pflichtfeld
  `ioi` mit – ohne sie ordnete das Backend die Anfrage keinem Objekt zu.

> ✅ **Die ChatGPT-App bleibt vollständig erhalten.** Die aktuelle Quelle ist ein
> **Superset** des deployten Builds: Die grafische Immobiliensuche `search_real_estate`
> samt Widget (`real-estate-board`) und Domain-Verifizierung ist unverändert enthalten
> (siehe 3.8) – es kommen nur die oben genannten Funktionen hinzu. Beim Ersetzen von
> `server/src/` gehen die ChatGPT-App-Funktionen **nicht** verloren; `web/dist/`
> ebenfalls beibehalten.
>
> **Build lokal verifiziert** (`tsc -p tsconfig.json`, Exit 0, alle 4 Module
> kompilieren fehlerfrei) – siehe 3.5.

### 3.2 Vollständiger Funktionsumfang (registrierte MCP-Tools)

| Tool | Zweck |
|---|---|
| `ping` | Health-Check |
| `search_real_estate` | **ChatGPT-App:** Immobiliensuche über den OpenImmo-Bestand (Ort, Preis, Zimmer, Ausstattung/Soft-Filter). Liefert die Treffer als **grafisches Widget** (`ui://widget/real-estate-board.html`) im ChatGPT-Client. Siehe Abschnitt 3.8. |
| `getExposeData` | Exposé-Daten (Preis, Makler, Finanzberater) per URL laden |
| `searchNearby` | POIs in der Umgebung via Google Places (Schulen, ÖPNV …) |
| `getCurrentDate` | Heutiges Datum + nächste 30 Tage (für relative Zeitangaben) |
| `createProcessCode` | Finanzierungsberechnung starten (ProcessCode) |
| `getFinanzierung` | Finanzierungsangebote zum ProcessCode abrufen |
| `updateFinanzierung` | Finanzierungsparameter anpassen |
| `createVorschlaege` | Personalisierte Vorschläge-Berechnung starten (anfrageId) – **ohne Objekt-OID**, Basis für Teil C |
| `getVorschlaege` | Personalisierte Vorschläge abrufen |
| `getCalendlyAvailability` | Freie Termine eines Finanzierungsberaters (Calendly) |
| `createCalendlyBooking` | Beratungstermin über Calendly buchen/vorbefüllen |
| `submitContactInquiry` | Kontaktanfrage über das Exposé-Kontaktformular senden (→ Makler/Anbieter) |
| `submitFinancingInquiry` | **NEU:** Finanzierungsanfrage direkt an den Finanzierungsberater senden (→ dessen eigenes Kontaktformular, NICHT den Makler) |

Zusätzlich intern (kein eigenständiges Tool, wird von `chat-baufinanzierung/advisor-resolver.php` über `GET /gpt/berater?url=...` aufgerufen): **`scrapeBeraterPage()`** – liefert Name, Titel, Telefon/Mobil, E-Mail, Foto, Calendly-Link einer persönlichen Berater-Seite.

### 3.3 Voraussetzungen (FreeBSD)

- **Node.js ≥ 18** (empfohlen 20):
  ```sh
  pkg install node20 npm-node20
  node --version   # v20.x+
  ```
- Für die **Calendly-Tools**: Playwright-Chromium (headless Browser-Automation):
  ```bash
  npx playwright install chromium
  ```
  Playwright liefert kein natives FreeBSD-Chromium-Binary. Läuft der bestehende
  Server bereits produktiv mit funktionierenden Calendly-Tools, ist die Lösung
  dafür (Linuxulator/`linux_base`, System-Chromium via `pkg install chromium` +
  `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH`, o.ä.) bereits vorhanden – 1:1
  übernehmen. Bei einer **Neuinstallation** vorab klären/testen; ohne
  funktionierendes Chromium bleibt der Rest des Assistenten nutzbar (siehe 3.7).
- Ausgehende HTTPS-Verbindungen zu `regionalimmobilien24.de`,
  `zbv.regionalimmobilien24.de`, Google Places und `calendly.com`.

### 3.4 Environment-Variablen (`.env`)

Aus `mcp-server/server/.env.example` (die Werte sind bereits die produktiven
Feed-Zugangsdaten – bitte im Team verifizieren):

| Variable | Bedeutung |
|---|---|
| `OPENIMMO_URL` | OpenImmo-Export-URL (Objektdatenbank) |
| `OPENIMMO_USER` / `OPENIMMO_PASS` | Basic-Auth für den Feed |
| `REFRESH_INTERVAL_HOURS` | (optional) XML-Refresh-Intervall, Default `24` |

Der Server lädt den OpenImmo-Feed **beim Start** herunter (mehrere hundert MB) und
danach periodisch.

> ⚠️ **Google-Places-Key ist aktuell hardcodiert** in `index.ts` (im `searchNearby`-
> Tool). Empfehlung: den Key per **API-/IP-Restriction**
> absichern und mittelfristig in eine Env-Variable auslagern. Wird die Umgebungs-
> suche nicht benötigt, kann `searchNearby` deaktiviert werden.

### 3.5 Build & lokaler Start

**Empfohlen – kompletter Workspace-Build (Server + ChatGPT-App-Widget):**

```bash
cd mcp-server
npm install                   # installiert server- und web-Workspace
npm run build                 # baut server (tsc → server/dist) UND web (vite → web/dist)
cd server
cp .env.example .env          # Werte prüfen/eintragen
node dist/index.js            # lauscht auf http://0.0.0.0:3000  →  /mcp/sse
```

Alternativ nur den Server bauen (das vorgebaute `web/dist/` bleibt erhalten):

```bash
cd mcp-server/server && cp .env.example .env && npm install && npm run build && node dist/index.js
```

> **Wichtig:** Das `web/dist/`-Bundle nicht löschen – es wird für die grafische
> ChatGPT-App-Immobiliensuche gebraucht (Abschnitt 3.8).

> Für Entwicklung ohne Build: `npm run dev` (nutzt `tsx`).

**Wichtig zu den relativen Pfaden:** Der Server erwartet als Arbeitsverzeichnis
den Ordner `server/`. Er greift auf **Geschwister-Ordner** zu:
`../web/dist/assets` (React-Widget-Bundle der ChatGPT-App, siehe 3.8) und `../calendly-cookies.json`
(Calendly-Session). Die Ordnerstruktur dieses Pakets bitte **so beibehalten**
(`mcp-server/server`, `mcp-server/web`, `mcp-server/calendly-cookies.json`).

### 3.6 Als Dienst betreiben (FreeBSD rc.d)

```sh
mkdir -p /opt/ri24-mcp
# server/, web/ und calendly-cookies.json als Geschwister nach /opt/ri24-mcp legen
cp mcp-server/deploy/ri24_mcp.rc /usr/local/etc/rc.d/ri24_mcp
chmod 755 /usr/local/etc/rc.d/ri24_mcp

sysrc ri24_mcp_enable="YES"
sysrc ri24_mcp_dir="/opt/ri24-mcp/server"
sysrc ri24_mcp_user="www"
sysrc ri24_mcp_logfile="/var/log/ri24-mcp.log"

chown -R www:www /opt/ri24-mcp
service ri24_mcp start
service ri24_mcp status
tail -f /var/log/ri24-mcp.log
```

Ausführliche Schritt-für-Schritt-Version (Node-Install, `.env`-Rechte,
Troubleshooting-Tabelle) siehe `mcp-server/CHATGPT-APP-DEPLOYMENT.md`.

- **nginx** (Reverse-Proxy, TLS, SSE-tauglich): `deploy/nginx-ri24-mcp.conf`
  nach `/usr/local/etc/nginx/conf.d/ri24-mcp.conf` kopieren, Server-Name +
  Zertifikatspfade anpassen. Entscheidend für Streaming: `proxy_buffering off;`
  und lange `proxy_read_timeout`. Danach `nginx -t && service nginx reload`.
  Der öffentliche MCP-Endpoint ist dann `https://<mcp-domain>/mcp/sse`.

### 3.7 ⚠️ Calendly-Session (sensibel)

`calendly-cookies.json` enthält eine **Admin-Session für calendly.com**. Sie ist
nötig, damit `getCalendlyAvailability` / `createCalendlyBooking` funktionieren.
Diese Cookies **laufen ab** – bei Fehlern in den Calendly-Tools muss die Datei
erneuert werden (frische Cookies eines eingeloggten Calendly-Admins). Datei
**vertraulich behandeln**, nicht in öffentliche Repos einchecken.

Funktionieren die Calendly-Tools nicht (fehlende Cookies / kein Chromium), bleibt
der Rest des Assistenten voll nutzbar – lediglich Terminabruf/-buchung entfällt.
Die Terminbuchung in `chat-baufinanzierung` läuft ohnehin bewusst nur als
Selbstbuchungs-Link (kein `createCalendlyBooking`-Tool-Call im Prompt).

### 3.8 ChatGPT-App (grafische Immobiliensuche) — NICHT verlieren!

Derselbe MCP-Server bedient **mehrere** Szenarien. Beim Update den
ChatGPT-App-Teil unbedingt erhalten:

1. **DeepChat-Assistenten** (Teil B/C): Chat im Exposé bzw. auf den
   Baufinanzierungs-Seiten, Text/JSON-Antworten.
2. **ChatGPT-App / Connector**: Der Server ist als Connector in ChatGPT einbindbar.
   Das Tool **`search_real_estate`** durchsucht den OpenImmo-Bestand und gibt die
   Treffer als **grafisches React-Widget** (`ui://widget/real-estate-board.html`)
   direkt im ChatGPT-Client aus (Immobilien-Board mit Bildern, Preis, Eckdaten).

Damit die ChatGPT-App funktioniert, sind zwingend nötig:

- **`web/dist/`** – das gebaute React-Widget-Bundle. Der Server liest es beim
  Tool-Aufruf aus `../web/dist/assets/` (relativ zum `server/`-Verzeichnis). Fehlt
  es, zeigt ChatGPT statt des Boards nur einen Platzhalter. **Beim Rebuild also die
  `web`-Workspace mitbauen** (`npm run build` im Root baut `server` **und** `web`)
  bzw. das mitgelieferte `web/dist/` beibehalten.
- **Domain-Verifizierung:** Der Server beantwortet `GET /.well-known/openai-apps-challenge`.
  ChatGPT nutzt das zur Verifizierung der MCP-Domain.
- **HTTPS** (siehe nginx-Config) – ChatGPT verbindet sich ausschließlich per HTTPS.

**MCP-Server-URL für den ChatGPT-Connector:** `https://<mcp-domain>/mcp/sse`

> Eine ausführliche, erprobte Schritt-für-Schritt-Anleitung speziell für dieses
> ChatGPT-App-Deployment (FreeBSD, nginx, SSL, ChatGPT-Connector) liegt dem Paket
> als **`mcp-server/CHATGPT-APP-DEPLOYMENT.md`** bei.

> **Hinweis zur Tool-Sichtbarkeit:** `search_real_estate` wird über `registerAppTool`
> (Apps SDK) registriert, die übrigen Tools über `registerTool`. Alle sind Teil
> desselben Servers und werden gemeinsam über `/mcp/sse` ausgeliefert.

---

## 4. Teil B – Exposé-Chat-Proxy (PHP) einbinden

### 4.1 Voraussetzungen (FreeBSD)

- **PHP ≥ 8.0** mit **cURL**-Extension, über **php-fpm** + nginx:
  ```sh
  pkg install php83 php83-curl php83-fpm
  sysrc php_fpm_enable="YES"
  service php-fpm start
  ```
  (Versionsnummer ggf. an das im Team bereits genutzte PHP-Paket anpassen –
  falls `www.regionalimmobilien24.de` schon auf demselben Server läuft, existiert
  php-fpm dort vermutlich bereits; dann nur den `chat/`-Ordner + nginx-Location
  ergänzen, siehe 4.4.)
- Erreichbar unter derselben Domain wie das Exposé (dann **kein CORS** nötig),
  z. B. `https://www.regionalimmobilien24.de/api/chat/chat.php`.

### 4.2 Konfiguration

Konfiguration per **Umgebungsvariablen** *oder* per `config.local.php`
(Kopie von `config.local.php.example`, wird von `config.php` automatisch geladen):

| Variable / Konstante | Bedeutung |
|---|---|
| `OPENAI_API_KEY` | OpenAI-Key (**Pflicht**, nur serverseitig!) |
| `OPENAI_MODEL` | Modell, Default `gpt-4.1` |
| `MCP_SERVER_URL` | **öffentliche** MCP-SSE-URL → `https://<mcp-domain>/mcp/sse` (**Pflicht**) |
| `MCP_SERVER_LABEL` | Label, Default `ri24` |
| `MCP_AUTHORIZATION` | optionaler Auth-Header für den MCP (leer, wenn keiner) |
| `CHAT_ALLOWED_ORIGINS` | CORS-Origins (kommagetrennt oder `*`); prod: die Exposé-Domain |
| `CHAT_INSTRUCTIONS_FILE` | Pfad zum System-Prompt, Default `../system-prompt.md` |

> `system-prompt.md` muss **eine Ebene über** `chat/` liegen (wie in diesem Paket),
> sonst `CHAT_INSTRUCTIONS_FILE` explizit setzen.

Empfehlung für Produktion: Key & URL als **Env-Vars** setzen, **nicht** als Datei.

> ⚠️ **php-fpm-spezifisch:** `getenv()` in `config.php` sieht per Default **keine**
> Shell-/`rc.conf`-Umgebungsvariablen – php-fpm reicht sie nur durch, wenn sie im
> jeweiligen Pool (z. B. `/usr/local/etc/php-fpm.d/www.conf`) explizit gesetzt sind:
> ```ini
> env[OPENAI_API_KEY] = sk-...
> env[MCP_SERVER_URL] = https://<mcp-domain>/mcp/sse
> ```
> Danach `service php-fpm reload`. Alternativ einfacher: `config.local.php` aus
> `config.local.php.example` anlegen und die Konstanten dort direkt definieren
> (Datei nicht öffentlich lesbar machen, `chmod 640`, `chown www:www`).

> ⚠️ **Session-Store von `chat.php`:** Der Gesprächsverlauf (`previous_response_id`)
> liegt unter `sys_get_temp_dir() . '/ri24-chat-sessions'`, also i. d. R. `/tmp`.
> Vor dem Deploy auf diesem Server prüfen, ob `clear_tmp_enable` (`rc.conf`, beim
> Boot) und/oder `daily_clean_tmp_enable` (`periodic.conf`, täglicher Cronjob)
> aktiv sind (`sysrc -n clear_tmp_enable`, `grep clean_tmp /etc/periodic.conf`).
> Ist eines davon aktiv, verliert `chat.php` bei Boot/periodischem Lauf das
> Gedächtnis laufender Gespräche (inkl. bereits genannter Kontaktdaten) –
> unabhängig von einem Deploy. Dasselbe gilt für den eigenen Session-Store von
> `chat-baufinanzierung/chat.php` (`/tmp/ri24-chat-baufi-sessions`, siehe 4a.2).

### 4.3 Frontend einbinden

1. Inhalt aus `chat/embed-snippet.html` ins Exposé-Template übernehmen.
2. Im Snippet die Konstante `ENDPOINT` auf den Produktionspfad setzen
   (z. B. `/api/chat/chat.php`).
3. `beispiel-expose-prototyp.html` zeigt eine vollständige Referenz mit **Inline-**
   *und* **Popup-Einbindung** des Widgets inkl. heyRegio-Branding.

Hinweis: `chat.php` setzt `X-Accel-Buffering: no`. Falls ein nginx davor steht,
für diesen Pfad zusätzlich `proxy_buffering off;` setzen, damit das Streaming
token-weise ankommt.

### 4.4 nginx-Location für `chat.php` (FreeBSD, php-fpm)

Falls `www.regionalimmobilien24.de` bereits über nginx + php-fpm läuft, reicht
eine Location im bestehenden Server-Block (Socket-Pfad ggf. anpassen,
`pkg info php83-fpm` zeigt den Default):

```nginx
location = /api/chat/chat.php {
    root           /usr/local/www/regionalimmobilien24;   # an reale Webroot anpassen
    fastcgi_pass   unix:/var/run/php-fpm.sock;
    fastcgi_index  chat.php;
    include        fastcgi_params;
    fastcgi_param  SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_buffering off;   # Streaming darf nicht gepuffert werden
    proxy_buffering    off;  # falls diese Location zusätzlich hinter einem proxy_pass liegt
}
```

Für `chat-baufinanzierung/chat.php` und `.../resolve-advisor.php` analog eine
zweite Location ergänzen (siehe 4a.4).

Nach Änderungen: `nginx -t && service nginx reload`.

---

## 4a. Teil C – Baufinanzierungs-Assistent (`chat-baufinanzierung/`)

Eigenständiger Chatbot, **kein** Exposé-Bezug (kein `expose_url`) – Kaufpreis,
PLZ und Objektart erfragt der Agent direkt im Gespräch. Nutzt denselben
MCP-Server wie Teil B, aber eigenen System-Prompt, eigenen Session-Store,
eigene Konfiguration (bewusst kein gemeinsamer Endpoint mit `chat/chat.php`,
um den produktiv laufenden Exposé-Chat nicht anzufassen).

Drei Einbindungswege, alle über denselben Proxy `chat-baufinanzierung/chat.php`:

1. **Eigene Berater-Seiten** (`chat-baufinanzierung/embed-snippet.html`) – auf
   JEDER persönlichen Finanzierungsberater-Seite einbinden (z. B.
   `.../vogtland/baufinanzierung/philipp-steppohn/`). Die Seite identifiziert
   den Berater selbst: Das Snippet schickt `window.location.href` als
   `berater_url`, der Server liest die Kontaktdaten live über
   `scrapeBeraterPage()` (siehe 3.1/3.2). Fallback (kein Netzzugriff/lokale
   Testumgebung): Dummy-Zuweisung aus `advisors.php`.
2. **Landingpage** (`baufinanzierung-landingpage/`, siehe Teil D) – eigene
   Unterseite mit automatischer Berater-Zuweisung über `?berater=`/Cookie.
3. **Externe Partner-Domains** (`partner-widget.js`, siehe Teil E) – feste,
   vorab hinterlegte `beraterId` statt Live-Scrape/Cookie.

### 4a.1 Voraussetzungen

Identisch zu Teil B (PHP ≥ 8.0 + cURL). Kann denselben php-fpm-Pool nutzen wie
`chat/`, sollte aber unter einem **eigenen Pfad** liegen (z. B.
`/api/chat-baufinanzierung/`), damit die getrennten Session-Stores und
Konfigurationen nicht kollidieren.

### 4a.2 Konfiguration

Wie 4.2, aber eigene Variablen (Präfix `CHAT_BAUFI_*`):

| Variable / Konstante | Bedeutung |
|---|---|
| `OPENAI_API_KEY` / `OPENAI_MODEL` | wie 4.2 – kann derselbe Key sein |
| `MCP_SERVER_URL` / `MCP_SERVER_LABEL` (Default `ri24-baufi`) / `MCP_AUTHORIZATION` | wie 4.2, derselbe MCP-Server |
| `CHAT_BAUFI_ALLOWED_ORIGINS` | CORS-Origins (kommagetrennt oder `*`) – **muss** um jede externe Partner-Domain erweitert werden (Teil E). Der Code spiegelt bei CORS immer die konkrete anfragende Origin (nicht das Literal `*`) zurück, daher funktioniert `*` auch mit `Access-Control-Allow-Credentials: true` für viele verschiedene Partner-Domains gleichzeitig. |
| `CHAT_BAUFI_INSTRUCTIONS_FILE` | Pfad zum System-Prompt, Default `../system-prompt-baufinanzierung.md` |
| `CHAT_BAUFI_VECTOR_STORE_ID` | OpenAI Vector-Store-ID für die Wissensdatenbank (`file_search`-Tool). Aktuell verknüpft: `vs_6a6860fef3988191ab2a5c9015556e27` (Quelle: `wissensbasis_baufinanzierung_chatbot_v1_4.json`, Stiftung Warentest). Leer lassen = kein `file_search`-Tool, kein Fehler. |

Session-Store: eigener Pfad `sys_get_temp_dir() . '/ri24-chat-baufi-sessions'`
(getrennt von `chat/`, siehe Hinweis in 4.2 zu `clear_tmp_enable`).

> ⚠️ **Vor Go-Live:** Dummy-Berater in `advisors.php` durch echte Daten
> ersetzen (Struktur/Keys beibehalten – `advisor-resolver.php`,
> `resolve-advisor.php`, `chat.php`, `partner-widget.js` verlassen sich
> darauf). Berater-Fotopfade (`photo`) sind aktuell **relativ zur
> Landingpage** gedacht (z. B. `assets/philipp-steppohn.png`) – für externe
> Partner-Widgets fällt ein nicht auflösbares Foto automatisch auf
> Initialen/Emoji zurück (siehe Teil E), bricht also nicht, sieht aber ohne
> absolute URL auf der Partnerseite nie das echte Foto.

### 4a.3 Frontend einbinden (eigene Berater-Seiten)

1. Inhalt aus `chat-baufinanzierung/embed-snippet.html` auf JEDER
   persönlichen Berater-Seite einbinden (nicht nur einer generischen
   Landingpage).
2. `ENDPOINT`/`RESOLVE_ADVISOR_ENDPOINT` auf die Produktionspfade setzen
   (z. B. `/api/chat-baufinanzierung/chat.php` bzw. `.../resolve-advisor.php`).
3. Widget zeigt einen dauerhaft sichtbaren Hinweis „🤖 KI-generierter Inhalt"
   über der Chat-Box (EU AI Act Art. 50 – Transparenzpflicht, siehe 6).

### 4a.4 nginx-Location (analog 4.4)

```nginx
location ~ ^/api/chat-baufinanzierung/(chat|resolve-advisor)\.php$ {
    root           /usr/local/www/regionalimmobilien24;
    fastcgi_pass   unix:/var/run/php-fpm.sock;
    fastcgi_index  chat.php;
    include        fastcgi_params;
    fastcgi_param  SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_buffering off;
    proxy_buffering    off;
}
```

---

## 4b. Teil D – Baufinanzierungs-Landingpage

`baufinanzierung-landingpage/Baufinanzierung-Prototyp-Chat.html` (Ziel-Pfad:
`/baufinanzierung/finanzierungsassistent`) – eigene Unterseite, same-origin zu
`chat-baufinanzierung/*.php` (kein CORS, Sticky-Cookie für Berater-Zuweisung
funktioniert dort ohne Zusatzaufwand).

1. Datei + `assets/` unter dem Ziel-Pfad ablegen.
2. Im `<script>`-Block am Dateiende: `RESOLVE_ENDPOINT` und `ENDPOINT` von
   `http://localhost:8001/...` auf die Produktionspfade umstellen (z. B.
   `/api/chat-baufinanzierung/resolve-advisor.php` bzw. `.../chat.php`).
3. Chat ist ein **offenes Inline-Widget** (kein Panel/Modal), Berater-Zuweisung
   läuft automatisch über `resolve-advisor.php` (URL-Parameter → Cookie →
   Zufall, siehe `advisor-resolver.php`).
4. Enthält denselben persistenten KI-Hinweis wie die anderen Widgets (im
   grünen Header-Balken über dem Chat).

---

## 4c. Teil E – Partner-Widget für externe Berater-Webseiten

Für Finanzierungsberater mit **eigener, nicht auf regionalimmobilien24.de
laufender** Domain: `chat-baufinanzierung/partner-widget.js` – Berater-Zuordnung
ist hier **fest hinterlegt** (`beraterId`) statt per Live-Scrape/Cookie, da sich
externe Domains nicht scrapen lassen. Kontaktdaten bleiben trotzdem zentral in
`advisors.php` gepflegt.

### 4c.1 Bereitstellung

`partner-widget.js` muss unter einer öffentlich erreichbaren, stabilen URL
liegen (Default in den Vorlagen: `https://www.regionalimmobilien24.de/api/chat-baufinanzierung/partner-widget.js`)
– das Skript läuft im Kontext der fremden Partnerseite, alle darin
angesprochenen Endpoints sind daher **absolute URLs**.

### 4c.2 Pro Partner: Kopiervorlage ausliefern

Zwei Darstellungsmodi, je eine Vorlage in `chat-baufinanzierung/`:

- `partner-widget-snippet-bubble.example.html` – Floating-Launcher unten
  rechts, öffnet beim Klick ein Chat-Panel. Partnerseite muss nichts
  vorbereiten.
- `partner-widget-snippet-inline.example.html` – offenes Inline-Widget direkt
  an der Stelle im HTML, an der das Snippet eingefügt wird.

Pro Berater nur zwei Werte in der Kopie anpassen:

```html
<script>
  window.RI24_BAUFI_PARTNER_WIDGET = {
    beraterId: 'philipp-steppohn',   // ← Key aus advisors.php
    mode: 'bubble',                  // oder 'inline'
    accentColor: '#c0392b'           // optional: Marken-Farbe des Partners statt RI24-Grün
  };
</script>
<script src="https://www.regionalimmobilien24.de/api/chat-baufinanzierung/partner-widget.js"></script>
```

`accentColor` (6-stelliger Hex-Code, optional) färbt Buttons, Header, Launcher
und Nutzer-Bubble; der helle Hintergrundton (KI-Bubble, Hinweis-Leiste) wird
automatisch als aufgehellte Variante berechnet. Fehlt/ungültig → RI24-Grün.

### 4c.3 CORS

`CHAT_BAUFI_ALLOWED_ORIGINS` (4a.2) um jede Partner-Domain erweitern, oder auf
`*` setzen (funktioniert wie in 4a.2 beschrieben auch mit Credentials, da der
Code die konkrete Origin zurückspiegelt statt eines Literal-Wildcards).

### 4c.4 Vor dem Rollout an Partner

1. Echte externe Berater als Einträge in `advisors.php` anlegen.
2. CORS wie 4c.3 erweitern.
3. Lokal testen: `chat-baufinanzierung/partner-widget-demo-bubble.html` bzw.
   `-inline.html` über einen lokalen PHP-Server öffnen (siehe
   `chat-baufinanzierung/README.md`, Abschnitt „Lokal testen").
4. **Bekannte Grenze:** kein Shadow-DOM – globale CSS-Resets auf der
   Partnerseite können das Widget verformen. Für den ersten Rollout bewusst
   einfach gehalten.

---

## 5. Verdrahtung & Test

1. MCP-Server läuft und ist öffentlich erreichbar – Smoke-Test:
   ```bash
   curl -N https://<mcp-domain>/mcp/sse
   # erwartet:  event: endpoint  /  data: /mcp/sse?sessionId=…
   ```
2. `MCP_SERVER_URL` in **beiden** PHP-Proxys (`chat/`, `chat-baufinanzierung/`)
   auf genau diese `…/mcp/sse`-URL setzen.
3. Exposé-Seite öffnen, Frage stellen (z. B. „Was bietet diese Immobilie?").
   Der Agent ruft `getExposeData` auf und antwortet gestreamt.
4. Golden-Prompts Exposé-Chat: Umgebung (`searchNearby`), Finanzierung
   (`createProcessCode`→`getFinanzierung`), Termin (`getCalendlyAvailability`),
   Kontakt (`submitContactInquiry`), Finanzierungsanfrage
   (`submitFinancingInquiry` – NICHT `submitContactInquiry`!).
5. Golden-Prompts Baufinanzierungs-Assistent: Rate/Optimierung
   (`createVorschlaege`/`getVorschlaege`), Wissensfrage (`file_search`, falls
   Vector-Store konfiguriert), „Wer ist mein Berater?" (Anzeige der über
   `berater_url`/`berater_id` aufgelösten Kontaktdaten).
6. Partner-Widget: Demo-Seite (4c.4) öffnen, Bubble öffnen, prüfen dass Name/
   Foto (oder Initialen-Fallback) des konfigurierten Beraters erscheinen und
   der KI-Hinweis sichtbar ist.

---

## 6. Sicherheit & Betrieb

- **OpenAI-Key** nur in den PHP-Proxys / als Server-Env – nie im Frontend, nie im Repo.
- **`calendly-cookies.json`**, **`.env`** und **beide `config.local.php`**
  (`chat/`, `chat-baufinanzierung/`) enthalten Geheimnisse → aus öffentlichen
  Repos ausschließen, restriktive Dateirechte. Dieses Paket enthält bewusst
  nur die `.example`-Vorlagen.
- **Gesprächsverlauf:** beide `chat.php` halten den Verlauf per
  `previous_response_id` in einem serverseitigen **Datei-Store**, gekeyt auf
  die vom Client gesendete `conversation_id` (`/tmp/ri24-chat-sessions/` bzw.
  `/tmp/ri24-chat-baufi-sessions/`). Bewusst **nicht** über die PHP-Session/
  Cookie – sonst geht der Verlauf bei cross-origin-Einbindung oder
  Cookie-Blocking verloren. Für horizontale Skalierung (mehrere Server) den
  Store durch einen gemeinsamen Speicher (z. B. Redis) ersetzen.
- **UI-Widgets / zwei Ausgabewege:** `search_real_estate` liefert ein
  Apps-SDK-Widget (`openai/outputTemplate`, `ui://widget/real-estate-board.html`),
  das **im ChatGPT-Client grafisch** rendert (dafür ist `web/dist/` **erforderlich**,
  siehe 3.8). In DeepChat (alle vier Widget-Oberflächen) rendern diese Widgets
  nicht – dort kommt Text/JSON an. `web/dist/` ist nur dann verzichtbar, wenn
  die ChatGPT-App **nicht** genutzt wird.
- **KI-Kennzeichnungspflicht (EU AI Act Art. 50):** Alle vier Widget-Oberflächen
  (Exposé-Chat, Baufinanzierungs-Chat, Landingpage, Partner-Widget) zeigen
  einen **dauerhaft sichtbaren** Hinweis „🤖 KI-generierter Inhalt" außerhalb
  des Nachrichten-Scrollbereichs (nicht nur einmalig in der Willkommens-
  nachricht). Wortlaut liegt jeweils als String-Konstante direkt im
  entsprechenden Snippet/Skript (`DISCLOSURE_TEXT` in `partner-widget.js`,
  inline in `embed-snippet.html`/Landingpage) – bei künftigen Wortlaut-
  Änderungen alle vier Stellen konsistent halten.
- **Logging:** Tool-Call-IDs, Latenzen und Fehlerpayloads mitschreiben; der Server
  loggt bereits ausführlich nach stdout (bei rc/systemd ins Logfile).
